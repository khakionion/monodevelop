#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/Library/Frameworks/Mono.framework/Versions/2.10.11/lib"
XML2_LIBS="-lxml2 -lz -lpthread  -liconv -lm "
XML2_INCLUDEDIR="-I/Library/Frameworks/Mono.framework/Versions/2.10.11/include/libxml2"
MODULE_VERSION="xml2-2.7.8"

